# Browser support

The library supports all popular browsers.
We aim to cover at least 99% of all users according to the Fingerprint Pro statistics.

At the moment, these browsers are:

- **Edge** 105+
- **Chrome** 65+
- **Firefox** 75+
- **Desktop Safari** 12.1+
- **Mobile Safari** 12.0+
- **Samsung Internet** 14.0+

Other browsers will probably also work, but we don't guarantee it.
