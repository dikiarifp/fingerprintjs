export default function getVendor(): string {
  return navigator.vendor || ''
}
